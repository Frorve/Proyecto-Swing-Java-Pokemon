package DreamTeam;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

import java.awt.Toolkit;

public class win extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private AdvancedPlayer player;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					win frame = new win();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public win() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(Test.class.getResource("/DreamTeam/ball.png")));
		setResizable(false);
		setTitle("¡Ganaste!");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 634, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));

		JPanel panel = new JPanel();
		contentPane.add(panel);

		ImageIcon losse = new ImageIcon("");
		panel.setLayout(null);

		ImageIcon imgWinIcon = new ImageIcon("/DreamTeam/gggg.png");

		JPanel panel_2 = new JPanel();
		panel_2.setBounds(10, 244, 176, 56);
		panel.add(panel_2);
		panel_2.setLayout(new GridLayout(1, 0, 0, 0));

		JPanel panel_3 = new JPanel();
		panel_3.setBounds(401, 244, 197, 56);
		panel.add(panel_3);
		panel_3.setLayout(new GridLayout(1, 0, 0, 0));

		// -----------------------------------Botón Volver---------------------------------------------------//

		ImageIcon volverIcon = new ImageIcon((win.class.getResource("/DreamTeam/vvv.png")));
		Image volver = volverIcon.getImage();
		Image volver2 = volver.getScaledInstance(180, 65, java.awt.Image.SCALE_SMOOTH);
		volverIcon = new ImageIcon(volver2);

		JButton volverb = new JButton();
		volverb.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	Test volver = new Test();
                volver.setVisible(true);
                dispose();
		    }
		});
		volverb.setIcon(volverIcon);
		panel_2.add(volverb);


		// ------------------------------------Botón Salir--------------------------------------------------//

		ImageIcon iconoSalir = new ImageIcon((win.class.getResource("/DreamTeam/Screenshot_1.png")));
		Image imagenSalir = iconoSalir.getImage();
		Image SAL = imagenSalir.getScaledInstance(195, 70, java.awt.Image.SCALE_SMOOTH);
		iconoSalir = new ImageIcon(SAL);

		JButton salir = new JButton(); // Establecer la imagen directamente al crear el botón
		salir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		salir.setIcon(iconoSalir);
		panel_3.add(salir);

		// --------------------------------------------------------------------------------------//

		JLabel etiJLabel = new JLabel(new ImageIcon(win.class.getResource("/DreamTeam/gggg.png")));
		etiJLabel.setBounds(4, -36, 600, 396);

		panel.add(etiJLabel);
		
        try {
            player = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/win.mp3"));
            player.setPlayBackListener(new PlaybackListener() {
                @Override
                public void playbackFinished(PlaybackEvent evt) {

                }
            });
            reproducirMusica();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }

	}
	
    private void reproducirMusica() {
        new Thread(() -> {
            try {
                player.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
}
