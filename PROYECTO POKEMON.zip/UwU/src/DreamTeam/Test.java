package DreamTeam;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JProgressBar;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;

public class Test extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private AdvancedPlayer player;
	private AdvancedPlayer player1;
	private AdvancedPlayer player2;
	private AdvancedPlayer player3;
	private AdvancedPlayer player4;
	private AdvancedPlayer player5;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Test frame = new Test();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Test() {
		setResizable(false);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Test.class.getResource("/DreamTeam/ball.png")));
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTitle("POKESWING");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1317, 729);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setMaximumSize(new Dimension(32774, 32771));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		ImageIcon icon2 = new ImageIcon((Test.class.getResource("/DreamTeam/background.jpg")));
		Image image2 = icon2.getImage(); 
        icon2 = new ImageIcon(image2);
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setBounds(1030, 357, 269, 186);
		ImageIcon icon = new ImageIcon((Test.class.getResource("/DreamTeam/boss1.png")));
		Image image = icon.getImage(); 
        icon = new ImageIcon(image);
        
        JLabel lblNewLabel_3 = new JLabel("");
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_3.setBounds(602, 646, 377, 106);
        ImageIcon icon4 = new ImageIcon((Test.class.getResource("/DreamTeam/accion.png")));
		Image image4 = icon4.getImage(); 
        Image newimg4 = image4.getScaledInstance(300,100,  java.awt.Image.SCALE_SMOOTH); 
        icon4 = new ImageIcon(newimg4);
        
        JLabel lblNewLabel_4 = new JLabel("");
        lblNewLabel_4.setVisible(false);
        
        JLabel lblNewLabel_6 = new JLabel("");
        lblNewLabel_6.setVisible(false);
        lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_6.setBounds(866, 443, 242, 187);
		ImageIcon icon6 = new ImageIcon((Test.class.getResource("/DreamTeam/hielo.png")));
		Image image6 = icon6.getImage(); 
        Image newimg6 = image6.getScaledInstance(300,300,  java.awt.Image.SCALE_SMOOTH); 
        icon6 = new ImageIcon(newimg6);
        lblNewLabel_6.setIcon(icon6);
   
        contentPane.add(lblNewLabel_6);
        
        JLabel lblNewLabel_7 = new JLabel("");
        lblNewLabel_7.setVisible(false);
        lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_7.setBounds(1030, 389, 258, 154);
		ImageIcon icon7 = new ImageIcon((Test.class.getResource("/DreamTeam/rayo.png")));
		Image image7 = icon7.getImage(); 
        Image newimg7 = image7.getScaledInstance(600,250,  java.awt.Image.SCALE_SMOOTH); 
        icon7 = new ImageIcon(newimg7);
        lblNewLabel_7.setIcon(icon7);
        contentPane.add(lblNewLabel_7);
        
        
        JLabel lblNewLabel_8 = new JLabel("");
        lblNewLabel_8.setVisible(false);
        lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_8.setBounds(1079, 357, 160, 254);
		ImageIcon icon8 = new ImageIcon((Test.class.getResource("/DreamTeam/roca.png")));
		Image image8 = icon8.getImage(); 
        Image newimg8 = image8.getScaledInstance(200,220,  java.awt.Image.SCALE_SMOOTH); 
        icon8 = new ImageIcon(newimg8);
        contentPane.add(lblNewLabel_8);
        
        lblNewLabel_8.setIcon(icon8);
        
        JLabel lblNewLabel_5_1 = new JLabel("HP - NECROGALEO");
        lblNewLabel_5_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_5_1.setForeground(Color.WHITE);
        lblNewLabel_5_1.setFont(new Font("OCR A Extended", Font.BOLD, 15));
        lblNewLabel_5_1.setBounds(1060, 285, 158, 21);
        contentPane.add(lblNewLabel_5_1);
        
        JProgressBar progressBar = new JProgressBar();
        progressBar.setValue(100);
        progressBar.setStringPainted(true);
        progressBar.setForeground(new Color(50, 205, 50));
        progressBar.setBounds(1018, 316, 232, 31);
        contentPane.add(progressBar);

        progressBar.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (progressBar.getValue() <= 20) {
                    progressBar.setForeground(Color.RED);
                } else {
                    progressBar.setForeground(new Color(50, 205, 50));
                }
            }
        });
        
        JLabel lblNewLabel_5 = new JLabel("HP - AEROTRES");
        lblNewLabel_5.setForeground(new Color(255, 255, 255));
        lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("OCR A Extended", Font.BOLD, 15));
        lblNewLabel_5.setBounds(699, 407, 137, 21);
        contentPane.add(lblNewLabel_5);
        
        JProgressBar progressBar_1 = new JProgressBar();
        progressBar_1.setValue(100);
        progressBar_1.setStringPainted(true);
        progressBar_1.setForeground(new Color(50, 205, 50));
        progressBar_1.setBounds(657, 438, 232, 31);
        contentPane.add(progressBar_1);
        
        progressBar_1.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                if (progressBar_1.getValue() <= 20) {
                    progressBar_1.setForeground(Color.RED);
                    try {
                    	if (progressBar_1.getValue() == 0 || progressBar.getValue() == 0) {
                    		player1.close();
                    	}
                        player1 = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/low.mp3"));
                        player1.setPlayBackListener(new PlaybackListener() {
                            @Override
                            public void playbackFinished(PlaybackEvent evt) {
//                            	reproducirMusica1();
                            }
                        });
                        reproducirMusica1();
                    } catch (JavaLayerException a) {
                        a.printStackTrace();
                    }
                } else {
                    progressBar_1.setForeground(new Color(50, 205, 50));
                }
            }
        });
        
        JButton btnNewButton_3 = new JButton("");
        btnNewButton_3.setContentAreaFilled(false);
        btnNewButton_3.setBorderPainted(false);
		ImageIcon icon13 = new ImageIcon((Test.class.getResource("/DreamTeam/rock.png")));
		Image image13 = icon13.getImage(); 
        Image newimg13 = image13.getScaledInstance(90,40,  java.awt.Image.SCALE_SMOOTH); 
        icon13 = new ImageIcon(newimg13);
        btnNewButton_3.setIcon(icon13);
        btnNewButton_3.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		lblNewLabel_8.setVisible(true);
        		
                try {
                    player3 = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/caida.mp3"));
                    player3.setPlayBackListener(new PlaybackListener() {
                        @Override
                        public void playbackFinished(PlaybackEvent evt) {

                        }
                    });
                    reproducirRoca();
                } catch (JavaLayerException o) {
                    o.printStackTrace();
                }
        		
				int randomValue1 = (int) (Math.random() * 11) + 5;
                int currentValue = progressBar.getValue();
                int newValue = Math.max(currentValue - randomValue1, 0);
                progressBar.setValue(newValue);
                
                int randomValue = (int) (Math.random() * 11) + 5;
                int currentOtherValue = progressBar_1.getValue();
                int newOtherValue = Math.max(currentOtherValue - randomValue, 0);
                progressBar_1.setValue(newOtherValue);
                
                if (newValue == 0) {
                	detenerMusica();
                    win winFrame = new win();
                    winFrame.setVisible(true);
                    dispose(); 
                } else if (newOtherValue == 0) {
                	detenerMusica();
                    losse loss = new losse();
                    loss.setVisible(true);
                    dispose(); 
                }
                
                Timer timer = new Timer(1500, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        lblNewLabel_8.setVisible(false);
                        ((Timer) e.getSource()).stop();
                    }
                });
                timer.setRepeats(false);
                timer.start();
        		
        	}
        });
        btnNewButton_3.setBounds(1172, 685, 105, 31);
        contentPane.add(btnNewButton_3);
        
        JButton btnAvalancha = new JButton("");
        btnAvalancha.setBorderPainted(false);
        btnAvalancha.setContentAreaFilled(false);
		ImageIcon icon11 = new ImageIcon((Test.class.getResource("/DreamTeam/ice.png")));
		Image image11 = icon11.getImage(); 
        Image newimg11 = image11.getScaledInstance(90,40,  java.awt.Image.SCALE_SMOOTH); 
        icon11 = new ImageIcon(newimg11);
        btnAvalancha.setIcon(icon11);
        btnAvalancha.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		lblNewLabel_6.setVisible(true);
        		
				int randomValue1 = (int) (Math.random() * 11) + 5;
                int currentValue = progressBar.getValue();
                int newValue = Math.max(currentValue - randomValue1, 0);
                progressBar.setValue(newValue);
                
                int randomValue = (int) (Math.random() * 11) + 5;
                int currentOtherValue = progressBar_1.getValue();
                int newOtherValue = Math.max(currentOtherValue - randomValue, 0);
                progressBar_1.setValue(newOtherValue);
                
                if (newValue == 0) {
                	detenerMusica();
                    win winFrame = new win();
                    winFrame.setVisible(true);
                    dispose(); 
                } else if (newOtherValue == 0) {
                	detenerMusica();
                    losse loss = new losse();
                    loss.setVisible(true);
                    dispose(); 
                }
                
                Timer timer = new Timer(800, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        lblNewLabel_6.setVisible(false);
                        ((Timer) e.getSource()).stop();
                    }
                });
                timer.setRepeats(false);
                timer.start();
        	}
        });
        btnAvalancha.setBounds(1172, 646, 105, 31);
        contentPane.add(btnAvalancha);
        
        JButton btnNewButton_1 = new JButton("");
        btnNewButton_1.setContentAreaFilled(false);
        btnNewButton_1.setBorderPainted(false);
		ImageIcon icon12 = new ImageIcon((Test.class.getResource("/DreamTeam/rayito.png")));
		Image image12 = icon12.getImage(); 
        Image newimg12 = image12.getScaledInstance(90,35,  java.awt.Image.SCALE_SMOOTH); 
        icon12 = new ImageIcon(newimg12);
        btnNewButton_1.setIcon(icon12);
        btnNewButton_1.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		lblNewLabel_7.setVisible(true);
        		
                try {
                    player4 = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/sonidoRayo.mp3"));
                    player4.setPlayBackListener(new PlaybackListener() {
                        @Override
                        public void playbackFinished(PlaybackEvent evt) {

                        }
                    });
                    reproducirRayo();
                } catch (JavaLayerException o) {
                    o.printStackTrace();
                }
        		
				int randomValue1 = (int) (Math.random() * 11) + 5;
                int currentValue = progressBar.getValue();
                int newValue = Math.max(currentValue - randomValue1, 0);
                progressBar.setValue(newValue);
                
                int randomValue = (int) (Math.random() * 11) + 5;
                int currentOtherValue = progressBar_1.getValue();
                int newOtherValue = Math.max(currentOtherValue - randomValue, 0);
                progressBar_1.setValue(newOtherValue);
                
                if (newValue == 0) {
                	detenerMusica();
                    win winFrame = new win();
                    winFrame.setVisible(true);
                    dispose(); 
                } else if (newOtherValue == 0) {
                	detenerMusica();
                    losse loss = new losse();
                    loss.setVisible(true);
                    dispose(); 
                }
                
                Timer timer = new Timer(1700, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        lblNewLabel_7.setVisible(false);
                        ((Timer) e.getSource()).stop();
                    }
                });
                timer.setRepeats(false);
                timer.start();
        	}
        });
        btnNewButton_1.setBounds(1057, 685, 105, 31);
        contentPane.add(btnNewButton_1);
        
        JButton btnNewButton_4 = new JButton("");
        btnNewButton_4.setBorderPainted(false);
        btnNewButton_4.setContentAreaFilled(false);
		ImageIcon icon14 = new ImageIcon((Test.class.getResource("/DreamTeam/escape.png")));
		Image image14 = icon14.getImage(); 
        Image newimg14 = image14.getScaledInstance(150,110,  java.awt.Image.SCALE_SMOOTH); 
        icon14 = new ImageIcon(newimg14);
        btnNewButton_4.setIcon(icon14);
        btnNewButton_4.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		System.exit(ABORT);
        	}
        });
        btnNewButton_4.setBounds(1280, 638, 95, 78);
        contentPane.add(btnNewButton_4);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.setBorderPainted(false);
        btnNewButton.setContentAreaFilled(false);
		ImageIcon icon10 = new ImageIcon((Test.class.getResource("/DreamTeam/lanzallamas.png")));
		Image image10 = icon10.getImage(); 
        Image newimg10 = image10.getScaledInstance(90,50,  java.awt.Image.SCALE_SMOOTH); 
        icon10 = new ImageIcon(newimg10);
        btnNewButton.setIcon(icon10);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		lblNewLabel_4.setVisible(true);
        		
                try {
                    player2 = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/sonidoLanzallamas.mp3"));
                    player2.setPlayBackListener(new PlaybackListener() {
                        @Override
                        public void playbackFinished(PlaybackEvent evt) {

                        }
                    });
                    reproducirLanzallamas();
                } catch (JavaLayerException o) {
                    o.printStackTrace();
                }
        		
				int randomValue1 = (int) (Math.random() * 11) + 5;
                int currentValue = progressBar.getValue();
                int newValue = Math.max(currentValue - randomValue1, 0);
                progressBar.setValue(newValue);
                
                int randomValue = (int) (Math.random() * 11) + 5;
                int currentOtherValue = progressBar_1.getValue();
                int newOtherValue = Math.max(currentOtherValue - randomValue, 0);
                progressBar_1.setValue(newOtherValue);
                
                if (newValue == 0) {
                	detenerMusica();
                    win winFrame = new win();
                    winFrame.setVisible(true);
                    dispose(); 
                } else if (newOtherValue == 0) {
                	detenerMusica();
                    losse loss = new losse();
                    loss.setVisible(true);
                    dispose(); 
                }
                
                Timer timer = new Timer(1500, new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        lblNewLabel_4.setVisible(false);
                        ((Timer) e.getSource()).stop();
                    }
                });
                timer.setRepeats(false);
                timer.start();
        	}
        });
        btnNewButton.setBounds(1057, 646, 105, 31);
        contentPane.add(btnNewButton);
        lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_4.setBounds(891, 443, 199, 168);
        contentPane.add(lblNewLabel_4);
        ImageIcon icon5 = new ImageIcon((Test.class.getResource("/DreamTeam/fuego.png")));
		Image image5 = icon5.getImage(); 
        icon5 = new ImageIcon(image5);
        
        lblNewLabel_4.setIcon(icon5);
        
        lblNewLabel_3.setIcon(icon4);
        contentPane.add(lblNewLabel_3);
        
        lblNewLabel_2.setIcon(icon);
        contentPane.add(lblNewLabel_2);
        
        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(657, 468, 224, 180);
        contentPane.add(lblNewLabel_1);
		ImageIcon icon3 = new ImageIcon((Test.class.getResource("/DreamTeam/pok.png")));
		Image image3 = icon3.getImage(); 
        icon3 = new ImageIcon(image3);
        
        lblNewLabel_1.setIcon(icon3);
        
        lblNewLabel.setIcon(icon2);
		lblNewLabel.setBounds(602, 263, 795, 494);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_Game = new JLabel("");
		lblNewLabel_Game.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_Game.setBounds(230, 90, 1530, 830);
        // Cargamos la imagen desde un recurso
        ImageIcon icon15 = new ImageIcon(Test.class.getResource("/DreamTeam/sw.png"));
        Image image15 = icon15.getImage();

        // Aplicamos el zoom a la imagen
        int newWidth = 1320; // Nueva anchura después del zoom
        int newHeight = 630; // Nueva altura después del zoom
        Image newimg15 = image15.getScaledInstance(newWidth, newHeight, java.awt.Image.SCALE_SMOOTH);
        ImageIcon zoomedIcon = new ImageIcon(newimg15);

        // Establecemos la imagen en el JLabel
        lblNewLabel_Game.setIcon(zoomedIcon);
		contentPane.add(lblNewLabel_Game);
		
        try {
            player = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/combat.mp3"));
            player.setPlayBackListener(new PlaybackListener() {
                @Override
                public void playbackFinished(PlaybackEvent evt) {
                	reproducirMusica();
                }
            });
            reproducirMusica();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
	}
	
    private void reproducirMusica() {
        new Thread(() -> {
            try {
                player.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void reproducirMusica1() {
        new Thread(() -> {
            try {
                player1.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void reproducirLanzallamas() {
        new Thread(() -> {
            try {
                player2.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void reproducirRoca() {
        new Thread(() -> {
            try {
                player3.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void reproducirRayo() {
        new Thread(() -> {
            try {
                player4.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void reproducirHielo() {
        new Thread(() -> {
            try {
                player5.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void detenerMusica() {
        player.close();
        player1.close();
}
}
