package DreamTeam;

import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackEvent;
import javazoom.jl.player.advanced.PlaybackListener;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class main extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private AdvancedPlayer player;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					main frame = new main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public main() {
		setResizable(false);
		setTitle("POKESWING");
		setIconImage(Toolkit.getDefaultToolkit().getImage(Test.class.getResource("/DreamTeam/ball.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 725, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIgnoreRepaint(true);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 711, 463);
		ImageIcon icon = new ImageIcon((Test.class.getResource("/DreamTeam/back.jpg")));
		Image image = icon.getImage(); 
        //Image newimg = image.getScaledInstance(600,250,  java.awt.Image.SCALE_SMOOTH); 
        icon = new ImageIcon(image);
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setBounds(145, 10, 448, 102);
		ImageIcon icon2 = new ImageIcon((Test.class.getResource("/DreamTeam/logo.png")));
		Image image2 = icon2.getImage(); 
        Image newimg2 = image2.getScaledInstance(300,100,  java.awt.Image.SCALE_SMOOTH); 
        icon2 = new ImageIcon(newimg2);
        
        JLabel lblNewLabel_1 = new JLabel("Felipe Toledano | Alejandro Castillo | Francisco Ortega");
        lblNewLabel_1.setFont(new Font("Segoe UI Black", Font.BOLD, 12));
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(176, 424, 394, 29);
        contentPane.add(lblNewLabel_1);
        lblNewLabel_2.setIcon(icon2);
        contentPane.add(lblNewLabel_2);
        
        JButton btnNewButton = new JButton("");
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		detenerMusica();
		    	Test volver = new Test();
                volver.setVisible(true);
                dispose();
        	}
        });
        
        btnNewButton.setBorderPainted(false);
        btnNewButton.setContentAreaFilled(false);
        btnNewButton.setFont(UIManager.getFont("CheckBoxMenuItem.font"));
        btnNewButton.setBounds(282, 313, 169, 59);
		ImageIcon icon4 = new ImageIcon((Test.class.getResource("/DreamTeam/continuar.png")));
		Image image4 = icon4.getImage(); 
        Image newimg4 = image4.getScaledInstance(150,90,  java.awt.Image.SCALE_SMOOTH); 
        icon4 = new ImageIcon(newimg4);
        btnNewButton.setIcon(icon4);
        contentPane.add(btnNewButton);

        
        textField = new JTextField();
        textField.setFont(new Font("OCR A Extended", Font.BOLD, 15));
        textField.setHorizontalAlignment(SwingConstants.CENTER);
        textField.setOpaque(false);
        textField.setBounds(282, 229, 169, 40);
        contentPane.add(textField);
        textField.setColumns(10);
        
        JLabel lblNewLabel_3 = new JLabel("");
        lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_3.setBounds(222, 133, 302, 102);
		ImageIcon icon3 = new ImageIcon((Test.class.getResource("/DreamTeam/usuario.png")));
		Image image3 = icon3.getImage(); 
        Image newim3 = image3.getScaledInstance(200,100,  java.awt.Image.SCALE_SMOOTH); 
        icon3 = new ImageIcon(newim3);
        lblNewLabel_3.setIcon(icon3);
        contentPane.add(lblNewLabel_3);
        
        lblNewLabel.setIcon(icon);
        contentPane.add(lblNewLabel);
		ImageIcon icon1 = new ImageIcon((Test.class.getResource("/DreamTeam/españita.jpg")));
		Image image1 = icon1.getImage(); 
        //Image newimg = image.getScaledInstance(600,250,  java.awt.Image.SCALE_SMOOTH); 
        icon1 = new ImageIcon(image1);
        
        try {
            player = new AdvancedPlayer(getClass().getResourceAsStream("/DreamTeam/opening.mp3"));
            player.setPlayBackListener(new PlaybackListener() {
                @Override
                public void playbackFinished(PlaybackEvent evt) {
                	reproducirMusica();
                }
            });
            reproducirMusica();
        } catch (JavaLayerException e) {
            e.printStackTrace();
        }
		
	}
	
    private void reproducirMusica() {
        new Thread(() -> {
            try {
                player.play();
            } catch (JavaLayerException e) {
                e.printStackTrace();
            }
        }).start();
    }
    
    private void detenerMusica() {
            player.close();
    }
}
